package application;
	
import gg.corporation.loja.controller.LojaGamesMenuListaController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {

			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/gg/corporation/loja/view/LojaGamesMenuLista.fxml"));
			Parent menuXML = loader.load();
			LojaGamesMenuListaController menu = loader.getController();
			Scene menuLayout = new Scene(menuXML);
			Stage menuJanela = new Stage();
			menuJanela.setTitle("Menu e Lista do Sistema");
			menuJanela.initModality(Modality.APPLICATION_MODAL);
			menuJanela.resizableProperty().setValue(Boolean.FALSE);
			menuJanela.setScene(menuLayout);
			menuJanela.show();			
			Rectangle2D posicaoJanela = Screen.getPrimary().getVisualBounds();
			menuJanela.setX((posicaoJanela.getWidth() - menuJanela.getWidth())/2);
			menuJanela.setY((posicaoJanela.getHeight() - menuJanela.getHeight())/2);
			menuJanela.setOnCloseRequest(
					event -> { 
						if (menu.onCloseQuery())
							System.exit(0);
						else
							event.consume();
					}
			); 		
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
