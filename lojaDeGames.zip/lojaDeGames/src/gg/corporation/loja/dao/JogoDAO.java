package gg.corporation.loja.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import gg.corporation.loja.entity.Jogo;

public class JogoDAO implements DAO<Jogo> {

	@Override
	public Object get(Long id) {
		Jogo jogo = null;
		String sql = "SELECT * FROM jogo WHERE id = ?";
		//Conex�o com o banco de dados
		Connection conexao = null;
		//Prepara��o de um comando sql
		PreparedStatement stm = null;
		//Guarda o retorno da opera��o sql
		ResultSet rset = null;
		try {
			//obtem conex�o com o banco
			conexao = Conexao.getConnection();
			//preparar o comando e seus par�metros
			stm = (PreparedStatement) conexao.prepareStatement(sql);
			stm.setInt(1, id.intValue());
			//executa a consulta e obtem as respostas
			rset = stm.executeQuery();
			while(rset.next()) {
				jogo = new Jogo();
				//atribui os valores lidos ao objetos
				jogo.setId(rset.getLong("id"));
				jogo.setGame(rset.getString("game"));
				jogo.setValor(rset.getDouble("valor"));
				jogo.setEmpresa(rset.getString("empresa"));
			}
		} catch(SQLException e) {
			System.out.println("Erro ao conectar ao banco de dados. Error: " + e);
		} finally {
			//Fecha todas as conex�es ap�s o seu uso
			try {
				if (stm != null)
					stm.close();
				if (conexao != null)
					conexao.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return jogo;
	}

	@Override
	public List<Jogo> getAll() {
		List<Jogo> jogos = new ArrayList<Jogo>();
		String sql = "SELECT * FROM jogo";
		//Conex�o com o banco de dados
		Connection conexao = null;
		//Prepara��o de um comando sql
		PreparedStatement stm = null;
		//Guarda o retorno da opera��o sql
		ResultSet rset = null;
		try {
			//obtem conex�o com o banco
			conexao = Conexao.getConnection();
			//preparar o comando e seus par�metros
			stm = (PreparedStatement) conexao.prepareStatement(sql);			
			//executa a consulta e obtem as respostas
			rset = stm.executeQuery();
			while(rset.next()) {
				Jogo jogo = new Jogo();
				//atribui os valores lidos ao objetos
				jogo.setId(rset.getLong("id"));
				jogo.setGame(rset.getString("game"));
				jogo.setValor(rset.getDouble("valor"));
				jogo.setEmpresa(rset.getString("empresa"));
				//Adiciona a lista de jogos o novo objeto
				jogos.add(jogo);
			}
		} catch(SQLException e) {
			System.out.println("Erro ao conectar ao banco de dados. Error: " + e);
		} finally {
			//Fecha todas as conex�es ap�s o seu uso
			try {
				if (stm != null)
					stm.close();
				if (conexao != null)
					conexao.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return jogos;
	}

	@Override
	public int create(Jogo jogo) {
		String sql = "INSERT INTO jogo (game, valor, empresa) VALUES (?,?,?)";
		//Conex�o com o banco de dados
		Connection conexao = null;
		//Prepara��o de um comando sql
		PreparedStatement stm = null;
		try {
			//obtem conex�o com o banco
			conexao = Conexao.getConnection();
			//preparar o comando e seus par�metros
			stm = (PreparedStatement) conexao.prepareStatement(sql);
			stm.setString(1, jogo.getGame());
			stm.setDouble(2, jogo.getValor());
			stm.setString(3, jogo.getEmpresa());
			//manda simpleste executar a opera��o
			stm.execute();		
		} catch(SQLException e) {
			System.out.println("Erro ao conectar ao banco de dados. Error: " + e);
		} finally {
			//Fecha todas as conex�es ap�s o seu uso
			try {
				if (stm != null)
					stm.close();
				if (conexao != null)
					conexao.close();
				return 1;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return 0;
	}

	@Override
	public boolean update(Jogo jogo, String[] params) {
		String sql = "UPDATE jogo SET game = ?, valor = ?, empresa = ? WHERE id = ?";
		//Conex�o com o banco de dados
		Connection conexao = null;
		//Prepara��o de um comando sql
		PreparedStatement stm = null;
		try {
			//obtem conex�o com o banco
			conexao = Conexao.getConnection();
			//preparar o comando e seus par�metros
			stm = (PreparedStatement) conexao.prepareStatement(sql);
			stm.setString(1, jogo.getGame());
			stm.setDouble(2, jogo.getValor());
			stm.setString(3, jogo.getEmpresa());
			stm.setLong(4, jogo.getId());
			//manda simpleste executar a opera��o
			stm.execute();		
		} catch(SQLException e) {
			System.out.println("Erro ao conectar ao banco de dados. Error: " + e);
		} finally {
			//Fecha todas as conex�es ap�s o seu uso
			try {
				if (stm != null)
					stm.close();
				if (conexao != null)
					conexao.close();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return false;
	}

	@Override
	public boolean delete(Jogo jogo) {
		String sql = "DELETE FROM jogo WHERE id = ?";
		//Conex�o com o banco de dados
		Connection conexao = null;
		//Prepara��o de um comando sql
		PreparedStatement stm = null;
		try {
			//obtem conex�o com o banco
			conexao = Conexao.getConnection();
			//preparar o comando e seus par�metros
			stm = (PreparedStatement) conexao.prepareStatement(sql);
			stm.setLong(1, jogo.getId());
			//manda simpleste executar a opera��o
			stm.execute();		
		} catch(SQLException e) {
			System.out.println("Erro ao conectar ao banco de dados. Error: " + e);
		} finally {
			//Fecha todas as conex�es ap�s o seu uso
			try {
				if (stm != null)
					stm.close();
				if (conexao != null)
					conexao.close();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return false;
	}

	public static void main(String[] args) {		
		JogoDAO dao = new JogoDAO();		
		//teste de cria��o
		Jogo novo = new Jogo();
		novo.setGame("Super Lixo");
		novo.setValor(25.00);
		novo.setEmpresa("Anonima Word");
		dao.create(novo);		
		novo.setGame("Taxolandia");
		novo.setEmpresa("Haddadim");
		novo.setValor(999.99);
		dao.create(novo);			
		//teste de consulta especifica
		Long id = new Long(5);
		Jogo busca = (Jogo) dao.get(id);
		if (busca != null) {
			System.out.println("Jogo encontrado no neme:" + busca.getGame());
			busca.setGame("Terraria");
			dao.update(busca, null);		
		}
		//teste de consulta gereal
		List<Jogo> catalogo = new ArrayList<Jogo>();
		catalogo = dao.getAll();		
		System.out.println("Cat�logos jogos: ");
		for(Jogo obj : catalogo) {
			System.out.println(obj.getGame());
			System.out.println(obj.getValor());
			System.out.println(obj.getEmpresa());
		}
		//teste de exclus�o
		//dao.delete(lista.get(0));
	}	
	
}
