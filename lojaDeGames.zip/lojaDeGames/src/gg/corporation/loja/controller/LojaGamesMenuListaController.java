package gg.corporation.loja.controller;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import gg.corporation.loja.dao.JogoDAO;
import gg.corporation.loja.entity.Jogo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class LojaGamesMenuListaController implements Initializable {

    @FXML
    private Button btnEditar;

    @FXML
    private Button btnExcluir;

    @FXML
    private Button btnIncluir;

    @FXML
    private Label lblEmpresa;

    @FXML
    private Label lblEmpresaValor;

    @FXML
    private Label lblJogo;

    @FXML
    private Label lblJogoValor;

    @FXML
    private Label lblPreco;

    @FXML
    private Label lblPrecoValor;

    @FXML
    private GridPane pnlBotoes;

    @FXML
    private GridPane pnlDetalhes;

    @FXML
    private TableColumn<Jogo, Long> tbcCodigo;

    @FXML
    private TableColumn<Jogo, String> tbcNomeJogo;

    @FXML
    private TableColumn<Jogo, Double> tbcValor;

    @FXML
    private TableView<Jogo> tbvJogos;
    
    private List<Jogo> listaJogos;
    private ObservableList<Jogo> observableListaJogo = FXCollections.observableArrayList();
    private JogoDAO jogoDAO;

    public static final String JOGO_EDITAR = " - Editar";
    public static final String JOGO_INCLUIR = " - Incluir";   
    
    /* GETTERS AND SETTERS \/ \/ \/ */
    
    public List<Jogo> getListaJogos() {
		return listaJogos;
	}

	public void setListaJogos(List<Jogo> listaJogos) {
		this.listaJogos = listaJogos;
	}

	public ObservableList<Jogo> getObservableListaJogo() {
		return observableListaJogo;
	}

	public void setObservableListaJogo(ObservableList<Jogo> observableListaJogo) {
		this.observableListaJogo = observableListaJogo;
	}

	public JogoDAO getJogoDAO() {
		return jogoDAO;
	}

	public void setJogoDAO(JogoDAO jogoDAO) {
		this.jogoDAO = jogoDAO;
	}

    /* INICIALIZA��O \/ \/ \/ */
	
	public boolean onCloseQuery() {
		Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
		alerta.setTitle("Confirma��o de sa�da");
		alerta.setHeaderText("Deseja sair do sistema?");
		ButtonType btnN = ButtonType.NO;
		ButtonType btnS = ButtonType.YES;
		alerta.getButtonTypes().setAll(btnS, btnN);
		Optional<ButtonType> resultado = alerta.showAndWait();
		return resultado.get() == btnS ? true : false;
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//Cria um obj: "DAO" para realizar as opera��es do banco de dados na tabela JOGO
		this.setJogoDAO(new JogoDAO());
		//Config Inicias -> tableView e carregamendo do banco
		this.carregarTableViewJogos();
		//Apaga a tabela de detalhes para n�o mostrar o desnecess�rio
		this.selecionarItemTableViewJogos(null);
		//Interagi com o painel de detalhes acionando um evento para o atualizar
		this.tbvJogos.getSelectionModel().selectedItemProperty().addListener(
				(Observable, oldValue, newValue) -> selecionarItemTableViewJogos(newValue)
		);
		//Preenche a tabela com conforme os dados salvos na lista
		this.tbvJogos.setItems(getObservableListaJogo());
	}

	private void carregarTableViewJogos() {
		//Configura��es da tabela com a propriedade coerente
		this.tbcCodigo.setCellValueFactory(new PropertyValueFactory<>("id"));
		this.tbcNomeJogo.setCellValueFactory(new PropertyValueFactory<>("game"));
		this.tbcValor.setCellValueFactory(new PropertyValueFactory<>("valor"));
		//Leitura da lista de jogos do banco
		this.setListaJogos(this.getJogoDAO().getAll());
		//Cria um obj observador que monitora as mudan�as na lista de jogos
		this.setObservableListaJogo(FXCollections.observableArrayList(this.getListaJogos()));
		//vincula o obj observable com a tabela de jogos
		//possibilita a atualiza��o autom�ticas da tabela ap�s opera��es no banco
		this.tbvJogos.setItems(this.getObservableListaJogo());
	}
	
	private void selecionarItemTableViewJogos(Jogo jogo) {
		//Se existe um Jogo selecionado
		if (jogo != null) {
			//atualiza a UI com os valores do jogo
			this.lblJogoValor.setText(jogo.getGame());
			this.lblPrecoValor.setText(String.valueOf(jogo.getValor()));
			this.lblEmpresaValor.setText(jogo.getEmpresa());
		}
		//se n�o existe jogo selecionado
		else {
			//atualiza a UI com os valores em branco
			this.lblJogoValor.setText("");
			this.lblPrecoValor.setText("");
			this.lblEmpresaValor.setText("");
		}
		
	}
	
	public boolean onShowTelaLojaGamesEditar(Jogo jogo, String operacao) {
		try {
			//carregando arquivo delayout LojaMenuEdit
			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/gg/corporation/loja/view/LojaGamesEdit.fxml"));
			Parent lojaGamesEditXML = loader.load(); //sistema diz que essa linha apresenta um erro
			//criando a janela nova (modal)
			Stage janelaLojaGamesEditar = new Stage();
			janelaLojaGamesEditar.setTitle("Cadastro de Jogo" + operacao);
			janelaLojaGamesEditar.initModality(Modality.APPLICATION_MODAL);
			janelaLojaGamesEditar.resizableProperty().setValue(Boolean.FALSE);
			//configura a scena
			Scene lojaGamesEditLayout = new Scene(lojaGamesEditXML);
			janelaLojaGamesEditar.setScene(lojaGamesEditLayout);
			//carregando o controlador e configurando o inicio
			LojaGamesEditController lojaGamesEditController = loader.getController();
			lojaGamesEditController.setJanelaLojaGamesEdit(janelaLojaGamesEditar);
			lojaGamesEditController.populaTela(jogo);
			//Mostra a janela e espera a opera��o encerrar
			janelaLojaGamesEditar.showAndWait();
			//Retorna o status da opera��o
			//true --->> SUCESSO
			//false -->> CANCELA
			return lojaGamesEditController.isOkClick();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/* CONFIGURA��ES DOS BOT�ES \/ \/ \/ */
	
    @FXML
    void onClickBtnIncluir(ActionEvent event) {
    	Jogo jogo = new Jogo();
    	boolean btnConfirmarClick = this.onShowTelaLojaGamesEditar(jogo,
    			LojaGamesMenuListaController.JOGO_INCLUIR);
    	
    	if (btnConfirmarClick) {
    		this.getJogoDAO().create(jogo);
    		this.carregarTableViewJogos();
    	}
    }

    @FXML
    void onClickBtnEditar(ActionEvent event) {
    	Jogo jogo = this.tbvJogos.getSelectionModel().getSelectedItem();
    	//Se existe um jogo selecionado a opera��o procede 
    	if (jogo != null) {
    		boolean btnConfirmarClick = this.onShowTelaLojaGamesEditar(jogo,
    				LojaGamesMenuListaController.JOGO_EDITAR);
    		if (btnConfirmarClick) {
    			this.getJogoDAO().update(jogo, null);
    			this.carregarTableViewJogos();
    		}
    	} else {
        		Alert alerta = new Alert(Alert.AlertType.ERROR);
        		alerta.setContentText("Para realizar uma ac�o escolha um dos itens na tabela!");
        		alerta.show();
        }
    }

    @FXML
    void onClickBtnExcluir(ActionEvent event) {
    	Jogo jogo = this.tbvJogos.getSelectionModel() .getSelectedItem();
    	if (jogo != null) {
    		Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
    		alerta.setTitle("Confirma��o de exclus�o");
    		alerta.setHeaderText("Voc� deseja realmente excluir o jogo " + jogo.getGame()+"?");
    		ButtonType botaoNao = ButtonType.NO;
    		ButtonType botaoSim = ButtonType.YES;
    		alerta.getButtonTypes().setAll(botaoSim,botaoNao);
    		//pegar resposta do usu�rio
    		Optional<ButtonType> resultado = alerta.showAndWait();
    		if (resultado.get() == botaoSim) {
    			this.getJogoDAO().delete(jogo);
    			this.carregarTableViewJogos();
    		}
    	}
    	else {
    		Alert alerta = new Alert(Alert.AlertType.ERROR);
    		alerta.setContentText("Para realizar uma ac�o escolha um dos itens na tabela!");
    		alerta.show();
    	}
    }



}
