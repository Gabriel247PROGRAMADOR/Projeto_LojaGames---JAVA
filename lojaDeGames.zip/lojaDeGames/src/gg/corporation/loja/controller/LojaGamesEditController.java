package gg.corporation.loja.controller;

import java.net.URL;
import java.util.ResourceBundle;

import gg.corporation.loja.entity.Jogo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LojaGamesEditController implements Initializable{

    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnConfirmar;

    @FXML
    private TextField txtEmpresa;

    @FXML
    private TextField txtGame;

    @FXML
    private TextField txtValor;
    
    //Obj Jogo
    private Jogo jogo;
    //flag da opera��o onclick
    private boolean okClick = false;
    //Refer�ncia a janela
    private Stage janelaLojaGamesEdit;
    
  public Stage getJanelaLojaGamesEdit() {
		return janelaLojaGamesEdit;
	}

	public void setJanelaLojaGamesEdit(Stage janelaLojaGamesEdit) {
		this.janelaLojaGamesEdit = janelaLojaGamesEdit;
	}

	//m�todo para preencher na tela os valores de um novo game
  	public void populaTela(Jogo jogo) {
  		//receber o novo valor para o jogo
  		this.jogo = jogo;
  		//atualizar a UI com os novos campos
  		this.txtGame.setText(jogo.getGame());
		this.txtValor.setText(String.valueOf(jogo.getValor()));
		this.txtEmpresa.setText(jogo.getEmpresa());
  	}
  	
  	private boolean validaCampos() {
  		String mensagemErros = new String();
  		String texto = this.txtValor.getText().trim();
  		
  		//validar o campo nome n�o pode ser branco
  		if (this.txtGame.getText() == null || 
  				this.txtGame.getText().trim().length() == 0) {
  			mensagemErros += "Informe o nome do jogo!\n";
  		}
  		//validar o campo valor n�o pode ser branco
  		if (this.txtValor.getText() == null || 
  				this.txtValor.getText().trim().length() == 0) {
  			mensagemErros += "Informe o valor!\n";
  		} else {
  		    try {
  		        double valor = Double.parseDouble(texto);
  		        
  		        if (valor < 0) {
  		            mensagemErros += "O valor n�o pode ser negativo!\n";
  		        }
  		    } catch (NumberFormatException e) {
  		        mensagemErros += "O valor deve ser um n�mero v�lido!\n";
  		    }
  		}
  		
  		//validar o campo valor n�o pode ser branco
  		if (this.txtEmpresa.getText() == null || 
  				this.txtEmpresa.getText().trim().length() == 0) {
  			mensagemErros += "Informe a empresa!\n";
  		}
  		
  		//Verifica se h� mensagens de erro
  		if (mensagemErros.length() == 0) {
  			return true;
  		}else {
  	    	Alert alerta = new Alert(Alert.AlertType.ERROR);
  	    	alerta.setTitle("Dados Inv�lidos");
  	    	alerta.setHeaderText("Favor corrgir as seguintes informa��es abaixo:\n\n");
  	    	alerta.setContentText(mensagemErros);
  	    	alerta.showAndWait();
  	    	return false;			
  		}
  	}

  	public boolean isOkClick() {
  		return okClick;
  	}

    @FXML
    void OnClickBtnConfirmar(ActionEvent event) {
    	if (validaCampos()) {
    		//coloca os valores adicionados pelo usu�rio
      		this.jogo.setGame(this.txtGame.getText());
      		this.jogo.setValor(Double.parseDouble(this.txtValor.getText()));
    		this.jogo.setEmpresa(this.txtEmpresa.getText());
    		//sinaliza o final da opera��o
    		this.okClick = true;
    		this.getJanelaLojaGamesEdit().close();
    	}
    }

    @FXML
    void OnClickBtnCancelar(ActionEvent event) {
    	this.getJanelaLojaGamesEdit().close();
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}

